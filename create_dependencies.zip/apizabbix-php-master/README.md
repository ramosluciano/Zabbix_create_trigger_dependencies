# Integração para recuperação de informações de gestão da ferramenta Zabbix

## Instalação:

- Requerimentos de sistema operacional:
  - Php
  - Composer

- Copiar o arquivo .env.example e adicionar valores de credenciais (sem aspas):

```sh
cp .env.example .env
vim .env
```

- Instalar as dependências de bibliotecas via composer:

```sh
composer install
```

- Definir as funções no arquivo apizabbix.php e rodar as mesmas no arquivo index.php:

```sh
php index.php
```
