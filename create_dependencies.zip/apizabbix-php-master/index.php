<?php

    require __DIR__ . '/apizabbix.php';

    $zabbixapi = new \ZabbixAPI;

    print_r(
        json_encode(
            $zabbixapi->get_hosts_com_ip_e_grupos_em_um_node("Recife"), 
            JSON_PRETTY_PRINT
        )
    );    

    // print_r(
    //     json_encode(
    //         $zabbixapi->get_hosts_com_ip_e_grupos_em_todos_os_nodes(),
    //         JSON_PRETTY_PRINT
    //     )
    // );
