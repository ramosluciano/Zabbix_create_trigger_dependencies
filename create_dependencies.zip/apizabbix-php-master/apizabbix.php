<?php

    require __DIR__ . '/vendor/autoload.php';

    /* 
    * Como instalar os certificados do serpro:
    * Ubuntu: https://gist.github.com/isaqueprofeta/8a99e45c3813a164fbcebb4ea935871b
    * Centos: https://gist.github.com/isaqueprofeta/3057a37903cab1cf50950e7421614f4e
    */

class ZabbixAPI
{

    public function __construct()
    {
        // Carrega credenciais de acesso ao zabbix definidas no .env
        $dotenv = new Dotenv\Dotenv(__DIR__);
        $dotenv->load();
        $this->user = getenv('ZABBIX_USUARIO');    
        $this->password = getenv('ZABBIX_SENHA');
      
    }


    /* 
    * Recebe no parametro do script a informação do servidor a conectar via API
    * Retorna a URL de conexao do servidor informado.
    */
    function get_url($URL = null)
    {
        // Recebendo o servidor por parâmetro para definir URL
        $url = $URL;

        $urls = [
            'servidor' => 'URL',
        ];
        
        return $urls[$url];
    }

    /* 
    * Realiza a conexão com o servidor Zabbix Alvo e retorna o objeto
    * utilizado nas operações.
    */
    function connect($user, $password)
    {
        global $url;
       
        //$client = new \GuzzleHttp\Client();
        $client = new \GuzzleHttp\Client(['verify' => false]);

        $URL = 'https://'.$url.'/api_jsonrpc.php';
        $zabbix = new \phpzabbix\PHPZabbix($client, $URL);

        try {
            $zabbix->login($user, $password);
        } catch (\Exception $e){
            print($e);
        }
        
        return $zabbix;
    }

    /* 
    * Função curinga que executa qualquer método informado nos parametros $action, $object e $options
    * Usado para métodos diferentes dos padroes (get, create, update, delete, import, export)
    * 
    */
    function action_object($method, $object, $options)
    {
        $api = $this->connect($this->user, $this->password);

        $api->$object->$method($options);

        $api->user->logout([]);
    }


    /* 
    * Busca dados do objeto informado em $object
    * no zabbix Alvo conforme parametros informados em $options
    * Retorna a array do indice 0. Utilizado para buscar dados de um unico objeto filtrado
    */
    function get_object($object, $options)
    {
        $api = $this->connect($this->user, $this->password);

        $object = $api->$object->get($options);

        $api->user->logout([]);

        return (!empty($object[0])) ? $object[0] : [];
        
    }

    /* 
    * Busca dados do objeto informado em $object
    * no zabbix Alvo conforme parametros informados em $options
    * Retorna a array completo. Utilizado para buscar dados de objeto com saida multipla, sem filtro unico
    */
    function get_objects($object, $options)
    {
        $api = $this->connect($this->user, $this->password);

        $object = $api->$object->get($options);

        $api->user->logout([]);

        return (!empty($object)) ? $object : [];
    }


    /* 
    * Exporta configuração em formato JSON ou XML de acordo com os parametros informados em $options
    * 
    */
    function export_config($options)
    {
        $api = $this->connect($this->user, $this->password);

        $object = $api->configuration->export($options);

        $api->user->logout([]);

        return (!empty($object)) ? $object : [];
    }

     /* 
    * Importa configuração em formato JSON ou XML de acordo com os parametros informados em $options
    * 
    */
    function import_config($options)
    {
        $api = $this->connect($this->user, $this->password);

        $object = $api->configuration->import($options);

        $api->user->logout([]);

        return (!empty($object)) ? $object : [];
    }

     /* 
    * Atualiza o objeto informado em $object
    * no zabbix Alvo conforme parametros informados em $options
    * 
    */
    function update_object($object, $options)
    {
        $api = $this->connect($this->user, $this->password);

        $object = $api->$object->update($options);

        $api->user->logout([]);

        return (!empty($object)) ? $object : null;
    }

       /* 
    * Deleta o objeto informado em $object
    * no zabbix Alvo conforme parametros informados em $options
    * 
    */
    function delete_object($object, $options)
    {
        
        $api = $this->connect($this->user, $this->password);

        $object = $api->$object->delete($options);

        $api->user->logout([]);

        return (!empty($object)) ? $object : null;
    }


    /* 
    * Cria objeto informado em $object
    * no zabbix Alvo conforme parametros informados em $options
    *  
    */
    function create_object($object, $options)
    {
        $api = $this->connect($this->user, $this->password);

        $object = $api->$object->create($options);

        $api->user->logout([]);

        return (!empty($object)) ? $object : [];
    }

    /* 
    * Consulta o sla do service informado
    * no zabbix Alvo conforme parametros informados em $options
    *  
    */
    function service_getsla($options)
    {
        $api = $this->connect($this->user, $this->password);

        $object = $api->service->getsla($options);

        $api->user->logout([]);

        return (!empty($object)) ? $object : [];
    }

    /* 
    * Atualiza interfaces do host pelas interfaces informadas 
    * no zabbix Alvo conforme parametros informados em $options
    * 
    */
    function replacehostinterfaces($object = 'hostinterface', $options)
    {
        $api = $this->connect($this->user, $this->password);

        $object = $api->$object->replacehostinterfaces($options);

        $api->user->logout([]);
        
        return (!empty($object)) ? $object : [];
    }


    /* 
    * Cria dependencia entre triggers 
    * no zabbix Alvo conforme parametros informados em $options
    * 
    */
    function triggerAdddependencies($options)
    {
        $api = $this->connect($this->user, $this->password);

        $object = $api->trigger->adddependencies($options);

        $api->user->logout([]);
        
        return (!empty($object)) ? $object : [];
    }
}
