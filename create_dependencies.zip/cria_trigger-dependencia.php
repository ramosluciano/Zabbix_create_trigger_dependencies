#!/usr/bin/php
<?php
/*
* * Criado por Luciano Ramos (ramosluci57@gmail.com)
* *  Agendamento personalizado de execução dos scripts para geração de relatórios de ANS
* *
*/
require './apizabbix-php-master/apizabbix.php';

// Conexao API
$zabbixapi = new \ZabbixAPI;
$url = $zabbixapi->get_url('servidor');

// Função que recupera dados da trigger de ping para o hostid informado
// Parametro 1: hostid
function get_triggerid($hostid){
	global $zabbixapi, $padrao_trigger_description;
	$options = [
		'output' => ['description'],
		'hostids' => $hostid,
		'monitored' => true,
		'selectDependencies' => ['triggerid', 'dependsOnTriggerid'],
		'search' => ['description' => $padrao_trigger_description]
	];
	$trigger = $zabbixapi->get_object('trigger', $options);
	if(!empty($trigger))
		return $trigger;
}

// Padroes para pesquisa:
$padrao_nome_grupo = 'Localidades/'; 
$padrao_nome_template = 'Template ICMP Ping WAN';
$padrao_trigger_description = 'indisponível há mais de 5 minutos';


// Coletando grupos de hosts
$options = [
		'search' => ['name' => $padrao_nome_grupo],
];
$grupos = $zabbixapi->get_objects('hostgroup', $options);

// Coletando template de Roteadores
$options = [
	'filter' => ['host' => $padrao_nome_template],
];
$template = $zabbixapi->get_object('template', $options);
$templateid = $template->templateid;

foreach($grupos as $grupo){
	// Coletando ID do Roteador da localidade
	$options = [
		'output' => ['host'],
		'groupids' => $grupo->groupid,
		'monitored_hosts' => true,
		'templateids' => $templateid,
	];
	$roteador = $zabbixapi->get_object('host', $options);
	if(empty($roteador)){
		echo 'WARNING: Grupo: '.$grupo->name.' - Sem roteador associado ao template correto'."\n";
	} else {
		$roteador_id = $roteador->hostid;
	
		// Coletando Hosts da localidade
		unset($options['templateids']);
		$hosts = $zabbixapi->get_objects('host', $options);

		// Coletando Triggerid da trigger do roteador
		$roteador_triggerid = get_triggerid($roteador_id)->triggerid;
		if(empty($roteador_triggerid)){
			echo 'ERROR: Grupo: '.$grupo->name.' - Roteador '.$roteador->host.' SEM trigger de PING'."\n";
		}

		// Varrendo hosts do grupo
		foreach($hosts as $host){
			if($host->hostid != $roteador_id){
				// Coletando triggerid da trigger do host
				$host_ = get_triggerid($host->hostid);
				if(empty($host_->triggerid)){
					echo 'ERROR: Grupo: '.$grupo->name.' -  Host '.$host->host.' SEM trigger de PING'."\n";
				} else {
					$dep = true;
					// Verificando se já existe a dependencia
					foreach($host_->dependencies as $dep){
					 	if($dep->triggerid == $roteador_triggerid){
							 echo 'INFORMATION: Grupo: '.$grupo->name.' - Host '.$host->host.' JÁ TEM dependencia criada com o roteador '.$roteador->host."\n"; 
							 $dep = false;
						}
					}
					// Criando a dependencia de trigger
					if($dep){
						$host_triggerid = $host_->triggerid;
						$options = [
							'triggerid' => $host_triggerid,
							'dependsOnTriggerid' => $roteador_triggerid
						];
						if($zabbixapi->triggerAddDependencies($options))
							echo 'SUCCESS: Grupo: '.$grupo->name.' - Criada Dependencia do Host '.$host->host.' para roteador '.$roteador->host."\n";
					}
				}
			}
		}
	}
}